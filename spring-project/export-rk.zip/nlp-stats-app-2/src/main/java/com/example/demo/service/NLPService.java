package com.example.demo.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import com.example.demo.model.NLPResult;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.*;
import org.springframework.stereotype.Service;
import java.util.Properties;
import java.util.HashMap;
@Service
public class NLPService {

 

	public NLPResult analyzeText(String text) {
        // Set up the Stanford CoreNLP pipeline
        Properties props = new Properties();
        props.setProperty("annotators", "tokenize,ssplit,pos,lemma,parse,sentiment");
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);

        // Create a document object
        CoreDocument document = pipeline.processToCoreDocument(text);

        // NLP statistics
        int wordCount = 0;
        int sentenceCount = document.sentences().size();
        int verbCount = 0;
        int commonNounCount = 0;
        int properNounCount = 0;
        
        double totalSentimentScore = 0;

        for (CoreSentence sentence : document.sentences()) {
            wordCount += sentence.tokens().size();
            totalSentimentScore += convertSentimentToScore(sentence.sentiment());
            
            for (CoreLabel token : sentence.tokens()) {
                if (token.tag().startsWith("VB")) {
                    verbCount++;
                }
                else if (token.tag().startsWith("NN") && !token.tag().equals("NNP") && !token.tag().equals("NNPS")) {
                	commonNounCount++;
                }
                else if (token.tag().equals("NNP") || token.tag().equals("NNPS")) {
                	properNounCount++;
                }
                
            }
        }

        double averageSentimentScore = totalSentimentScore / sentenceCount;
        // Assuming average sentiment score as sentiment polarity for simplicity
        // Stanford CoreNLP does not provide a direct measure of subjectivity

        // Create NLPResult object
        NLPResult result = new NLPResult();
        result.setWordCount(wordCount);
        result.setSentenceCount(sentenceCount);
        result.setVerbCount(verbCount);
        result.setCommonNounCount(commonNounCount);
        result.setProperNounCount(properNounCount);
        result.setSentimentPolarity(averageSentimentScore);
        // Set a default value for sentiment subjectivity or calculate as needed
        result.setSentimentSubjectivity(0.5); // Placeholder value

        return result;
    }

    private double convertSentimentToScore(String sentiment) {
        switch (sentiment) {
            case "Very negative":
                return 0;
            case "Negative":
                return 0.25;
            case "Neutral":
                return 0.5;
            case "Positive":
                return 0.75;
            case "Very positive":
                return 1;
            default:
                return 0.5;
        }
    }
    
//    public NLPResult readAggregatedResults() {
//        NLPResult aggregatedResult = new NLPResult();
//        try {
//            List<String> lines = Files.readAllLines(Paths.get("D:/nlp_task_RA/aggregated_results.csv"));
//            System.out.println("************Printing Lines Here*****************");
//            System.out.println(lines);
//            System.out.println(lines.size());
//            if (lines.size() > 1) {
//                // Assuming the first line is the header
//                String[] headers = lines.get(0).startsWith(",") ? lines.get(0).substring(1).split(",") : lines.get(0).split(",");//header.split(",");
//                String[] values = lines.get(1).startsWith(",") ? lines.get(1).substring(1).split(",") : lines.get(1).split(",");//lines.get(1).split(",");
//                System.out.println("Headers " + headers);
//                System.out.println("Values " + values);
//                Map<String, Integer> headerMap = new HashMap<>();
//
//                // Map the header to its index
//                for (int i = 0; i < headers.length; i++) {
//                    headerMap.put(headers[i].trim(), i);
//                }
//
//                // Read values based on the header, with null checks
////                int a = parseIntegerValue(headerMap, values, "word_count");
////                System.out.println("Word Count" + a);
//                aggregatedResult.setWordCount(parseIntegerValue(headerMap, values, "word_count"));
//                aggregatedResult.setSentenceCount(parseIntegerValue(headerMap, values, "sentence_count"));
//                aggregatedResult.setVerbCount(parseIntegerValue(headerMap, values, "verb_count"));
//                aggregatedResult.setCommonNounCount(parseIntegerValue(headerMap, values, "common_noun_count"));
//                aggregatedResult.setProperNounCount(parseIntegerValue(headerMap, values, "proper_noun_count"));
//                aggregatedResult.setSentimentPolarity(parseDoubleValue(headerMap, values, "sentiment_polarity"));
////                aggregatedResult.setSentimentSubjectivity(parseDoubleValue(headerMap, values, "sentimentSubjectivity"));
//            }
//        } catch (IOException e) {
//            System.out.println("Error reading aggregated results.");
//            e.printStackTrace();
//        }
//        return aggregatedResult;
//    }
//
//    private Integer parseIntegerValue(Map<String, Integer> headerMap, String[] values, String key) {
//        if (headerMap.containsKey(key)) {
//            try {
//                return Integer.parseInt(values[headerMap.get(key)]);
//            } catch (NumberFormatException e) {
//                System.out.println("Error parsing integer for key: " + key);
//            }
//        }
//        return 0; // Default value if key not found or parsing error
//    }
//
//    private Double parseDoubleValue(Map<String, Integer> headerMap, String[] values, String key) {
//        if (headerMap.containsKey(key)) {
//            try {
//                return Double.parseDouble(values[headerMap.get(key)]);
//            } catch (NumberFormatException e) {
//                System.out.println("Error parsing double for key: " + key);
//            }
//        }
//        return 0.0; // Default value if key not found or parsing error
//    }
    public NLPResult readAggregatedResults() {
        NLPResult aggregatedResult = new NLPResult();
        try {
            List<String> lines = Files.readAllLines(Paths.get("D:/nlp_task_RA/aggregated_results.csv"));
            System.out.println("Lines: " + lines);
            System.out.println("Lines Size: " + lines.size());
            for(int j = 0; j < lines.size(); j++) {
            	String[] data = lines.get(j).split(",");
            	System.out.println("data[0]" + data[0]);
            	System.out.println("data[1]" + data[1]);
            	System.out.println(lines.get(j).split(","));
            	
            }
            if (!lines.isEmpty()) {
                // Assuming the second line is the one with data
//            	String[] data = lines.get(1).split(",");
                Map<String, String> resultMap = new HashMap<>();

                // Iterate over the data and populate the map
                for (int i = 0; i < lines.size(); i++) {
                	String[] data = lines.get(i).split(",");
                    //if (i + 1 < lines.size()) { // Make sure we have a pair
                        resultMap.put(data[0].trim(), data[1].trim());
                        
                    //}
                }
                System.out.println("ResultMap: " + resultMap);
                // Parse and set values to aggregatedResult
                aggregatedResult.setWordCount(parseIntegerValue(resultMap, "word_count"));
                aggregatedResult.setSentenceCount(parseIntegerValue(resultMap, "sentence_count"));
                aggregatedResult.setVerbCount(parseIntegerValue(resultMap, "verb_count"));
                aggregatedResult.setCommonNounCount(parseIntegerValue(resultMap, "common_noun_count"));
                aggregatedResult.setProperNounCount(parseIntegerValue(resultMap, "proper_noun_count"));
                aggregatedResult.setSentimentPolarity(parseDoubleValue(resultMap, "sentiment_polarity"));
                aggregatedResult.setSentimentSubjectivity(parseDoubleValue(resultMap, "sentiment_subjectivity"));
            }
        } catch (IOException e) {
            System.out.println("Error reading aggregated results.");
            e.printStackTrace();
        }
        return aggregatedResult;
    }

    private Integer parseIntegerValue(Map<String, String> resultMap, String key) {
        try {
            // Use Double.parseDouble to handle values that are not whole numbers
            return (int) Math.round(Double.parseDouble(resultMap.getOrDefault(key, "0")));
        } catch (NumberFormatException e) {
            System.out.println("Error parsing integer for key: " + key);
            return 0;
        }
    }


    private Double parseDoubleValue(Map<String, String> resultMap, String key) {
        try {
            return Double.parseDouble(resultMap.getOrDefault(key, "0.0"));
        } catch (NumberFormatException e) {
            System.out.println("Error parsing double for key: " + key);
            return 0.0;
        }
    }

}

