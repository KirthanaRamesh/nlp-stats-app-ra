package com.example.demo.model;

public class NLPResult {
    private int wordCount;
    private int sentenceCount;
    private int verbCount;
    private int commonNounCount;
    private int properNounCount;
    private double sentimentPolarity;
    private double sentimentSubjectivity;

    // Constructor
    public NLPResult() {
    }

    // Getters and Setters
    public int getWordCount() {
        return wordCount;
    }

    public void setWordCount(int wordCount) {
        this.wordCount = wordCount;
    }

    public int getSentenceCount() {
        return sentenceCount;
    }

    public void setSentenceCount(int sentenceCount) {
        this.sentenceCount = sentenceCount;
    }

    public int getVerbCount() {
        return verbCount;
    }

    public void setVerbCount(int verbCount) {
        this.verbCount = verbCount;
    }
    
    public int getCommonNounCount() {
        return commonNounCount;
    }

    public void setCommonNounCount(int commonNounCount) {
        this.commonNounCount = commonNounCount;
    }
    
    public int getProperNounCount() {
        return properNounCount;
    }

    public void setProperNounCount(int properNounCount) {
        this.properNounCount = properNounCount;
    }
    

    public double getSentimentPolarity() {
        return sentimentPolarity;
    }

    public void setSentimentPolarity(double sentimentPolarity) {
        this.sentimentPolarity = sentimentPolarity;
    }

    public double getSentimentSubjectivity() {
        return sentimentSubjectivity;
    }

    public void setSentimentSubjectivity(double sentimentSubjectivity) {
        this.sentimentSubjectivity = sentimentSubjectivity;
    }

    // Optionally, override toString() for easy printing of the object's state
    @Override
    public String toString() {
        return "NLPResult{" +
                "wordCount=" + wordCount +
                ", sentenceCount=" + sentenceCount +
                ", verbCount=" + verbCount +
                ", sentimentPolarity=" + sentimentPolarity +
                ", sentimentSubjectivity=" + sentimentSubjectivity +
                '}';
    }
}
